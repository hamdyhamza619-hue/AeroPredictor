package com.example.aeropredictor

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var latest: TextView
    private lateinit var stats: TextView
    private lateinit var history: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button

    private val rounds = mutableListOf<Double>()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val busy = AtomicBoolean(false)
    private var lastCapturedValue: Double? = null
    private val captureRequestCode = 501

    @Deprecated("Use Activity Result APIs in a production app")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequestCode) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = mgr.getMediaProjection(resultCode, data)
                beginCapture()
            } else {
                status.text = "لم يتم السماح بمشاركة الشاشة."
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 34, 28, 24)
            setBackgroundColor(0xFF101D30.toInt())
        }
        fun label(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView =
            TextView(this).apply { text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER; setPadding(4, 12, 4, 12) }

        outer.addView(label("✈ AERO PREDICTOR", 25f))
        status = label("جاهز — افتح اللعبة ثم اضغط بدء القراءة", 15f, 0xFFB9C7D9.toInt())
        outer.addView(status)
        latest = label("آخر نتيجة: --", 30f, 0xFF7BE28B.toInt())
        outer.addView(latest)

        startButton = Button(this).apply {
            text = "بدء قراءة الشاشة"
            setOnClickListener {
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), captureRequestCode)
            }
        }
        stopButton = Button(this).apply {
            text = "إيقاف القراءة"
            isEnabled = false
            setOnClickListener { stopCapture() }
        }
        outer.addView(startButton)
        outer.addView(stopButton)

        stats = label("الإحصائيات ستظهر بعد قراءة النتائج", 15f, 0xFFFFFFFF.toInt())
        outer.addView(stats)
        outer.addView(label("سجل الجولات", 18f))
        history = label("لا توجد نتائج مسجلة بعد", 14f, 0xFFD5DDEA.toInt())
        val scroll = ScrollView(this)
        scroll.addView(history)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        outer.addView(label("تنبيه: يعرض التطبيق النتائج المقروءة وإحصاءاتها فقط؛ لا يمكنه معرفة انفجار الجولة القادمة.", 12f, 0xFFFFD28A.toInt()))
        setContentView(outer)
    }

    private fun beginCapture() {
        try {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi
            reader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
            virtualDisplay = projection?.createVirtualDisplay(
                "AeroPredictorCapture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader?.surface, null, handler
            )
            startButton.isEnabled = false
            stopButton.isEnabled = true
            status.text = "يقرأ الشاشة الآن… اترك شاشة اللعبة ظاهرة."
            handler.post(captureRunnable)
        } catch (e: Exception) {
            status.text = "تعذر بدء القراءة: ${e.localizedMessage ?: "خطأ غير معروف"}"
            stopCapture()
        }
    }

    private val captureRunnable = object : Runnable {
        override fun run() {
            val image = reader?.acquireLatestImage()
            if (image != null) processImage(image)
            if (projection != null) handler.postDelayed(this, 1000)
        }
    }

    private fun processImage(image: Image) {
        if (!busy.compareAndSet(false, true)) { image.close(); return }
        val mediaImage = image
        val input = try { InputImage.fromMediaImage(mediaImage, 0) } catch (e: Exception) {
            mediaImage.close(); busy.set(false); return
        }
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val text = result.text
                val regex = Regex("""(?i)(\d{1,4}(?:[.,]\d{1,2})?)\s*[x×]""")
                val found = regex.findAll(text).mapNotNull {
                    it.groupValues[1].replace(',', '.').toDoubleOrNull()
                }.filter { it >= 1.0 && it <= 100000.0 }.lastOrNull()
                if (found != null && found != lastCapturedValue) {
                    lastCapturedValue = found
                    runOnUiThread { addRound(found) }
                }
            }
            .addOnFailureListener { }
            .addOnCompleteListener {
                mediaImage.close()
                busy.set(false)
            }
    }

    private fun addRound(value: Double) {
        rounds.add(0, value)
        if (rounds.size > 500) rounds.removeAt(rounds.lastIndex)
        latest.text = "آخر نتيجة: ${format(value)}x"
        val under15 = rounds.count { it < 1.5 }
        val under2 = rounds.count { it < 2.0 }
        val over5 = rounds.count { it >= 5.0 }
        val n = rounds.size.toDouble()
        stats.text = "عدد الجولات: ${rounds.size}\n" +
            "المتوسط المسجل: ${format(rounds.average())}x\n" +
            "أقل من 1.5x: ${(under15 / n * 100).roundToInt()}%\n" +
            "أقل من 2x: ${(under2 / n * 100).roundToInt()}%\n" +
            "5x فأكثر: ${(over5 / n * 100).roundToInt()}%"
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        history.text = rounds.take(100).mapIndexed { i, v ->
            "${i + 1}. ${format(v)}x"
        }.joinToString("\n")
        status.text = "آخر قراءة مؤكدة: $stamp — ${rounds.size} نتيجة"
    }

    private fun format(value: Double): String = String.format(Locale.US, "%.2f", value)

    private fun stopCapture() {
        handler.removeCallbacks(captureRunnable)
        virtualDisplay?.release()
        virtualDisplay = null
        reader?.close()
        reader = null
        projection?.stop()
        projection = null
        startButton.isEnabled = true
        stopButton.isEnabled = false
        status.text = "تم إيقاف قراءة الشاشة."
    }

    override fun onDestroy() {
        stopCapture()
        recognizer.close()
        super.onDestroy()
    }
}
